# Fluid
[Fluid](http://www.fluidapp.com/) Turn Your Favorite Web Apps into Real
Mac Apps.

## Usage

```puppet
include fluid
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
